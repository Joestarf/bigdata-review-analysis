# 多语言重复内容识别：研究交接包

本包可独立读取中英文及混杂正文，输出A—E分数、暂定是否重复、程度和复核标记。所有决策都是review，
尚不支持自动降权；余弦或逻辑回归分数不是校准后的真实重复概率。
不含原评论、用户、标注正文、向量缓存或评分更新。原英文评分交接包另行保留。

安装 requirements-inference.txt 后运行：
python -m src.multilingual_inference --input your_pairs.csv --output pair_scores.csv
python -m src.redundancy_degree --input your_pairs.csv --output pair_degrees.csv
输入至少两列 text_a,text_b，可带 pair_id,asin,review_id_a,review_id_b。
首次使用按固定提交下载多语言预训练编码器；此下载不在本压缩包中。

完整说明见 report/multilingual_adaptation.md。训练需完整研究仓库和本地冻结数据；
本公开包的训练脚本仅随运行版本保存，不包含重新训练所需数据。
只加载可信来源的joblib文件。模型清单校验文件SHA和配套运行代码版本。
