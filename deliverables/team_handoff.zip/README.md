# Team model and rating handoff

## Prepared rating data
Unzip to a new directory. data/product_final_ratings.csv contains default experimental weighted star ratings for all 1,000 sampled ASINs. data/product_ratings.csv contains six strategies.
Default: light 0.75, moderate 0.50, same wording 0.25, extra five-field record copy 0; short/semantic-only signals retain weight 1.
Formula: sum(weight * rating) / sum(weight). Original stars are not altered.
Recompute from all 90,750 review-level rows without original Amazon data:
    python -m src.rating_adjustment --weights data/review_weights.csv --output recomputed_product_ratings.csv

## Frozen model use
Install requirements-inference.txt in a compatible environment. Original runtime: Arch WSL / Python 3.14. Exact sklearn/joblib versions preserve artifact compatibility. GPU is optional.
The fixed MiniLM revision downloads on first semantic inference unless already cached.
    from src.portable import PortablePredictor
    p = PortablePredictor(".")
    result = p.predict_pairs([("The battery lasts all day.", "A full charge lasts me a whole day.")])

CSV scoring from input columns asin,review_id,text:
    python -m src.portable --bundle . --input new_reviews.csv --output new_pairs.csv
Outputs five method rows per pair; all decisions stay review. Only load trusted joblib files.
models/portable_manifest.json contains the artifact hashes.

## Scope and delivery
These are experimental information-redundancy policies, not authenticity labels or official product stars.
No method met the validation target; reference labels lack independent human verification.
No transitive near-duplicate grouping. Rankings cover only the sampled 1,000 ASINs.
The reports explain policy, actual performance and sampling bias.
bundle_manifest.json checks every other archive member; the separate .sha256 checks this ZIP.
Obtain the separate LOCAL team_research_private.zip from the project owner for original review text, fixed labels and cached vectors. Keep the sealed test as the original final evaluation, not a tuning set.
