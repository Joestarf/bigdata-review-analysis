# Data provenance
Source: [McAuley-Lab/Amazon-Reviews-2023](https://huggingface.co/datasets/McAuley-Lab/Amazon-Reviews-2023).
Category: Cell_Phones_and_Accessories; fixed derived sample 90,750 reviews / 1,000 ASINs.
Public contents: project review IDs, ratings, experimental weights, product aggregates and numerical candidate scores.
No full review-body columns, original user ID columns or timestamps. Review IDs are pseudonymous lookup keys, not guaranteed irreversible anonymization.
Original download revision was not recorded. Existing SHA fixes this sample; re-downloading creates a new version.
The upstream dataset card checked for this handoff did not state an explicit license. No general redistribution permission for original text is assumed; original data stays in the separate local research archive.
